from __future__ import print_function

import boto3, json, logging, requests, time, os

logger = logging.getLogger()
logger.setLevel(logging.INFO)

sns = boto3.client('sns')

#SMS Phone Number
phone_number=os.environ.get('SMS_NUMBER')

#Check Point Management Server Info
cp_url=os.environ.get('CHECKPOINT_API_URL')
cp_user=os.environ.get('CHECKPOINT_API_USER')
cp_pass=os.environ.get('CHECKPOINT_API_PASS')
policy_layer=os.environ.get('POLICY_LAYER')
publish_sleep_timer=10
cp_sid=[]


def CreateScript():
   
    #Login and get SID
    
    url=cp_url+'/login' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla'} #Set Headers
    data = {'user': cp_user, 'password': cp_pass} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    cp_sid = jsonreturn['sid'] #Capture SID and store in cp_sid variable
    print('SID: '+cp_sid)
    
    print("----[ Create Gateway Objects ]----")
    
    #Create Gateway
    url=cp_url+'/add-simple-gateway' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'InternalGateway','ip-address':'172.10.10.100','color':'blue'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Gateway
    url=cp_url+'/add-simple-gateway' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'DMZGateway','ip-address':'10.10.1.1','color':'orange'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Gateway
    url=cp_url+'/add-simple-gateway' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'ExternalGateway','ip-address':'172.123.154.1','color':'red'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Gateway
    url=cp_url+'/add-simple-gateway' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'PartnerGateway','ip-address':'172.15.15.1','color':'orange'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    print("----[ Create Host Objects ]----")
    
    #Create Host
    url=cp_url+'/add-host' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'NginxServer','ip-address':'172.10.10.10','color':'orange'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Host
    url=cp_url+'/add-host' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'SplunkServer','ip-address':'172.10.10.20','color':'blue'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Host
    url=cp_url+'/add-host' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'RadiusServer','ip-address':'172.10.10.30','color':'red'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Host
    url=cp_url+'/add-host' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'TerminalServer','ip-address':'172.10.10.40','color':'orange'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Host
    url=cp_url+'/add-host' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'CitrixServer','ip-address':'172.10.10.50','color':'orange'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Host
    url=cp_url+'/add-host' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'RSAServer','ip-address':'172.10.10.60','color':'red'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    #Create Host
    url=cp_url+'/add-host' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'DockerServer','ip-address':'172.10.10.70','color':'blue'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    
    print("----[ Create Group Objects ]----")
    
    #Create Docker Services Group
    url=cp_url+'/add-service-group' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'DockerServices','tags':'Docker','comments':'Group of Public Ports Used By Docker Containers'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    
    print("----[ Create Network Objects ]----")
    
    #Create Network
    url=cp_url+'/add-network' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'Internal','subnet':'172.1.16.0','mask-length':'24'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Network
    url=cp_url+'/add-network' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'MgmtNet','subnet':'172.20.20.0','mask-length':'24'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Network
    url=cp_url+'/add-network' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'WebServers','subnet':'10.10.10.0','mask-length':'24'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    print("----[ Create Rules ]----")
    
    #Create Rule - nbt
    
    url=cp_url+'/add-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer, 'position': 'top', 'name':'Netbios', 'source':'any', 'destination':'any', 'service':'NBT', 'action':'accept', 'track':'none'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Rule - docker
    
    url=cp_url+'/add-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer, 'position': 'top', 'name':'Docker Containers', 'source':'ExternalZone', 'destination':'DockerServer', 'service':'DockerServices', 'action':'accept', 'track':'log'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Rule - term server
    
    url=cp_url+'/add-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer, 'position': 'top', 'name':'Terminal Services', 'source':'MgmtNet', 'destination':'TerminalServer', 'service':'Remote_Desktop_Protocol', 'action':'accept', 'track':'log'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Rule - auth
    
    url=cp_url+'/add-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer, 'position': 'top', 'name':'RSA Access', 'source':'Internal', 'destination':'RSAServer', 'service':'secureid-udp', 'action':'accept', 'track':'log'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Rule - citrix
    
    url=cp_url+'/add-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer, 'position': 'top', 'name':'Internal Citrix', 'source':'Internal', 'destination':'CitrixServer', 'service':'Citrix', 'action':'accept', 'track':'log'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Rule - outbound
    
    url=cp_url+'/add-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer, 'position': 'top', 'name':'Internal Outbound', 'source':'Internal', 'destination':'Internet', 'service':['http','https','ssh'], 'action':'accept', 'track':'log'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Rule - block apps
    
    url=cp_url+'/add-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer, 'position': 'top', 'name':'Blocked Apps', 'source':'Internal', 'destination':'Internet', 'service':['Facebook','Twitter','YouTube','Hulu','Netflix','DropBox'], 'action':'drop', 'track':'log'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    #Create Rule - stealth rule
    
    url=cp_url+'/add-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer, 'position': 'top', 'name':'Stealth Rule', 'source':'any', 'destination':['InternalGateway','DMZGateway','ExternalGateway','PartnerGateway'], 'service':'any', 'action':'drop', 'track':'log'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Rule - Splunk LEA
    
    url=cp_url+'/add-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer, 'position': 'top', 'name':'LEA Logging', 'source':['InternalGateway','DMZGateway','ExternalGateway','PartnerGateway'], 'destination':'SplunkServer', 'service':'FW1_lea', 'action':'accept', 'track':'log'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    #Create Rule - mgmt rule
    
    url=cp_url+'/add-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer, 'position': 'top', 'name':'Network Mgmt', 'source':'MgmtNet', 'destination':['InternalGateway','DMZGateway','ExternalGateway','PartnerGateway'], 'service':['https','ssh','icmp-proto','snmp'], 'action':'accept', 'track':'log'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    print("----[ Create Access Sections ]----")
    
    #Create Section - Cleanup
    
    #url=cp_url+'/add-access-section' #Set API URL
    #headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    #data = {'layer': policy_layer, 'position':{ 'above':'Cleanup rule'}, 'name':'Cleanup Rules'} #Set POST Data
    #r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    #jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    #print(jsonreturn)
    
    #Create Section - Misc
    
    url=cp_url+'/add-access-section' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer, 'position':{ 'above':'Netbios'}, 'name':'Misc'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Section - Docker Section
    
    url=cp_url+'/add-access-section' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer, 'position':{ 'above':'Docker Containers'}, 'name':'Docker Public Services'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    #Create Section - Internal Access
    
    url=cp_url+'/add-access-section' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer, 'position':{ 'above':'Internal Citrix'}, 'name':'Internal Access'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Section - Internal Outbound
    
    url=cp_url+'/add-access-section' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer, 'position':{ 'above':'Blocked Apps'}, 'name':'Outbound'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Section - Mgmt Rules
    
    url=cp_url+'/add-access-section' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer, 'position':{ 'above':'Network Mgmt'}, 'name':'Network Management'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    
    
    print("----[ Publish Session ]----")
    
    #Publish Session
    
    url=cp_url+'/publish' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    #data = {''} #Set POST Data
    r = requests.post(url, data='{}', headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    time.sleep(publish_sleep_timer)
    
    print("---[ Logout Session ]----")
    
    #Logout
    
    url=cp_url+'/logout' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    #data = {''} #Set POST Data
    r = requests.post(url, data='{}', headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn['message'])




def DeleteScript():
    print("---[ Login ]----")

    #Login and get SID
    
    url=cp_url+'/login' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla'} #Set Headers
    data = {'user': cp_user, 'password': cp_pass} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    cp_sid = jsonreturn['sid'] #Capture SID and store in cp_sid variable
    print('SID: '+cp_sid)
    
    print("----[ Delete Rules ]----")
    
    #Delete Rule - nbt
    
    url=cp_url+'/delete-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer,'name':'Netbios'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Rule - docker
    
    url=cp_url+'/delete-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer,'name':'Docker Containers'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Rule - term server
    
    url=cp_url+'/delete-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer,'name':'Terminal Services'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Rule - auth
    
    url=cp_url+'/delete-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer,'name':'RSA Access'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Rule - citrix
    
    url=cp_url+'/delete-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer,'name':'Internal Citrix'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Rule - outbound
    
    url=cp_url+'/delete-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer,'name':'Internal Outbound'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Rule - block apps
    
    url=cp_url+'/delete-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer,'name':'Blocked Apps'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    #Delete Rule - stealth rule
    
    url=cp_url+'/delete-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer,'name':'Stealth Rule'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Rule - Splunk LEA
    
    url=cp_url+'/delete-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer,'name':'LEA Logging'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    #Delete Rule - mgmt rule
    
    url=cp_url+'/delete-access-rule' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer,'name':'Network Mgmt'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    
    print("----[ Delete Gateway Objects ]----")
    
    #Delete Gateway
    url=cp_url+'/delete-simple-gateway' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'InternalGateway'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Gateway
    url=cp_url+'/delete-simple-gateway' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'DMZGateway'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Gateway
    url=cp_url+'/delete-simple-gateway' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'ExternalGateway'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Create Gateway
    url=cp_url+'/delete-simple-gateway' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'PartnerGateway'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    print("----[ Delete Host Objects ]----")
    
    #Delete Host
    url=cp_url+'/delete-host' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'NginxServer'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Host
    url=cp_url+'/delete-host' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'SplunkServer'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Host
    url=cp_url+'/delete-host' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'RadiusServer'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Host
    url=cp_url+'/delete-host' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'TerminalServer'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Host
    url=cp_url+'/delete-host' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'CitrixServer'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Host
    url=cp_url+'/delete-host' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'RSAServer'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    #Delete Host
    url=cp_url+'/delete-host' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'DockerServer'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    
    print("----[ Delete Access Sections ]----")
    
    #Delete Section - Cleanup
    
    url=cp_url+'/delete-access-section' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer,'name':'Cleanup Rules'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Section - Misc
    
    url=cp_url+'/delete-access-section' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer,'name':'Misc'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Section - Docker Section
    
    url=cp_url+'/delete-access-section' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer,'name':'Docker Public Services'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    #Delete Section - Internal Access
    
    url=cp_url+'/delete-access-section' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer,'name':'Internal Access'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Section - Internal Outbound
    
    url=cp_url+'/delete-access-section' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer,'name':'Outbound'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Section - Mgmt Rules
    
    url=cp_url+'/delete-access-section' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'layer': policy_layer,'name':'Network Management'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    print("----[ Delete Group Objects ]----")
    
    #Delete Docker Services Group
    url=cp_url+'/delete-service-group' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'DockerServices'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    
    
    print("----[ Delete Network Objects ]----")
    
    #Delete Network
    url=cp_url+'/delete-network' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'Internal'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Network
    url=cp_url+'/delete-network' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'MgmtNet'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Network
    url=cp_url+'/delete-network' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'WebServers'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    #Delete Docker TCP Service
    url=cp_url+'/delete-service-tcp' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'NginxContainer'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON

    #Delete Docker TCP Service
    url=cp_url+'/delete-service-tcp' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'SQLContainer'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON     
    
    #Delete Docker TCP Service
    url=cp_url+'/delete-service-tcp' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'MinecraftContainer'} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    
    print("----[ Publish Session ]----")
    
    #Publish Session
    
    url=cp_url+'/publish' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    #data = {''} #Set POST Data
    r = requests.post(url, data='{}', headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    time.sleep(publish_sleep_timer)
    
    print("---[ Logout Session ]----")
    
    #Logout
    
    url=cp_url+'/logout' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    #data = {''} #Set POST Data
    r = requests.post(url, data='{}', headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn['message'])
    
    
    
def UpdateScript():
    #Login and get SID
    
    url=cp_url+'/login' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla'} #Set Headers
    data = {'user': cp_user, 'password': cp_pass} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    cp_sid = jsonreturn['sid'] #Capture SID and store in cp_sid variable
    print('SID: '+cp_sid)
    
    
    #Create Docker TCP Service
    url=cp_url+'/add-service-tcp' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'NginxContainer','port':'4565','tags':'Docker','groups':['DockerServices']} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON

    #Create Docker TCP Service
    url=cp_url+'/add-service-tcp' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'SQLContainer','port':'7854','tags':'Docker','groups':['DockerServices']} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON     
    
    #Create Docker TCP Service
    url=cp_url+'/add-service-tcp' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    data = {'name':'MinecraftContainer','port':'5455','tags':'Docker','groups':['DockerServices']} #Set POST Data
    r = requests.post(url, data=json.dumps(data), headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    
    
    #Publish Session
    
    url=cp_url+'/publish' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    #data = {''} #Set POST Data
    r = requests.post(url, data='{}', headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn)
    
    time.sleep(publish_sleep_timer)
    
    print("---[ Logout Session ]----")
    
    #Logout
    
    url=cp_url+'/logout' #Set API URL
    headers = {'Content-type': 'application/json', 'Accept': 'bla', 'X-chkp-sid': cp_sid} #Set Headers
    #data = {''} #Set POST Data
    r = requests.post(url, data='{}', headers=headers, verify=False) #Send POST request
    jsonreturn = json.loads(r.text) #Convert and store API reply as JSON
    print(jsonreturn['message'])



def lambda_handler(event, context):
    logger.info('Received event: ' + json.dumps(event))
    message = json.dumps(event)
    parse = json.loads(message)
    msg = parse['clickType']
    if str(msg) == 'SINGLE':
        sns.publish(PhoneNumber=phone_number, Message='Creating Check Point Rulebase...') #Send SMS Message
        CreateScript()
        sns.publish(PhoneNumber=phone_number, Message='Rulebase Created!') #Send SMS Message
   
    if str(msg) == 'LONG':
        sns.publish(PhoneNumber=phone_number, Message='Updating Rulebase') #Send SMS Message
        UpdateScript()        
        
    if str(msg) == 'DOUBLE':
        sns.publish(PhoneNumber=phone_number, Message='Deleting Rulebase, Have A Nice Day!') #Send SMS Message
        DeleteScript()
        
        
  
        
        
        
        
        
        
        
        
        
        
        
        
   
        
        
        
           
